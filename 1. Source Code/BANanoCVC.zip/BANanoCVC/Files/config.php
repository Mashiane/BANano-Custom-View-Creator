<?php
const DB_HOST = '127.0.0.1';
const DB_NAME = 'ewarehouse';
const DB_USER = 'root';
const DB_PASS = '';
?>